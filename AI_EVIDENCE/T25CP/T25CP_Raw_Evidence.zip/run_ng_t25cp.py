"""New bounded TLV767 model-scope diagnostics; standalone portable ngspice 42."""
from pathlib import Path
import subprocess, time, hashlib, json, re
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'ng-results-v2'
OUT.mkdir(exist_ok=True)
LIB=ROOT/'vendor'/'TLV76701_TRANS.lib'
ENGINE=ROOT/'runtime'/'Spice64'/'bin'/'ngspice_con.exe'
assert hashlib.sha256(LIB.read_bytes()).hexdigest()=='8dc150de2dfdf2e7562dd0656970ffc7750537d0f88966fc4f776bf5f71a2e2a'
# Windows ngspice codemodel treats quote characters literally; this workspace has no spaces.
# v1 preserved under ng-results: loader diagnostic, not an electrical/solver failure.
(OUT/'.spiceinit').write_text('set ngbehavior=ps\n'+''.join('codemodel '+p.as_posix()+'\n' for p in sorted((ROOT/'runtime'/'Spice64'/'lib'/'ngspice').glob('*.cm'))),encoding='ascii')
cases=[
 ('reverse_forced3p3_VIN0','0','V_FORCE REG 0 3.3',False),
 ('pulse12_10us_CC280','PWL(0 5.5 2m 5.5 2.001m 12 2.011m 12 2.012m 5.5)','I_LOAD REG 0 0.280',True),
 ('pulse12_100us_CC280','PWL(0 5.5 2m 5.5 2.001m 12 2.101m 12 2.102m 5.5)','I_LOAD REG 0 0.280',True),
 ('collapse1us_Rlight','PWL(0 5.5 2m 5.5 2.001m 0)','R_LOAD REG 0 1Meg',True),
 ('collapse1us_R280','PWL(0 5.5 2m 5.5 2.001m 0)','R_LOAD REG 0 11.785714285714',True),
]
summary=[]
for name,source,load,tran in cases:
    cir=OUT/(name+'.cir')
    if cir.exists(): raise RuntimeError('Refusing unchanged rerun '+name)
    command='tran 20n 3m 0 20n' if tran else 'op'
    cir.write_text(f'''T25CP {name} - scope diagnostic only
.lib "{LIB.as_posix()}"
V_SRC VIN 0 {source}
X_LDO VIN FB 0 VIN REG TLV76701_TRANS
R_TOP REG FB 31.6k
R_BOT FB 0 10k
C_IN VIN 0 1u
R_ESR REG CO 0.01
C_OUT CO 0 10u
{load}
.options tnom=25
.temp 25
.control
set wr_vecnames
set wr_singlescale
{command}
wrdata {name}.csv v(VIN) v(REG) v(FB) i(V_SRC)
quit
.endc
.end
''',encoding='ascii')
    row={'case':name,'deck_sha256':hashlib.sha256(cir.read_bytes()).hexdigest(),'analysis':'TRAN' if tran else 'DC', 'scope':'ISOLATED_NOMINAL_MODEL_SCOPE_TEST_NO_HARDWARE_PASS'}
    start=time.monotonic()
    with (OUT/(name+'.stdout.txt')).open('wb') as so,(OUT/(name+'.stderr.txt')).open('wb') as se:
        try:
            proc=subprocess.run([str(ENGINE),'-b','-o',name+'.log',cir.name],cwd=OUT,stdout=so,stderr=se,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
            row.update(status='ENGINE_RETURNED',returncode=proc.returncode)
        except subprocess.TimeoutExpired:
            row.update(status='WALL_TIMEOUT',actual_simulated_progress='UNKNOWN')
    row['wall_seconds']=time.monotonic()-start
    log=(OUT/(name+'.log')).read_text(errors='replace') if (OUT/(name+'.log')).exists() else ''
    row['errors']=[l for l in log.splitlines() if re.search('error|aborted|failed|timestep too small',l,re.I)]
    csv=OUT/(name+'.csv')
    data=[]
    if csv.exists():
        for line in csv.read_text().splitlines()[1:]:
            try: data.append([float(v) for v in line.split()])
            except ValueError: pass
    row['rows']=len(data)
    row['completed']=bool(data) and not row['errors'] and (not tran or abs(data[-1][0]-.003)<1e-10)
    if data:
        row['final_row']=data[-1]
        if tran:
            row['last_simulated_time_s']=data[-1][0]
            pre=[r for r in data if .0015<=r[0]<=.0019]
            post=[r for r in data if r[0]>=.002]
            row['valid_prestate']=bool(pre) and min(r[2] for r in pre)>3.15 and max(r[2] for r in pre)<3.5 and max(r[2] for r in pre)-min(r[2] for r in pre)<.001
            row['pre_vout_minmax']=[min(r[2] for r in pre),max(r[2] for r in pre)] if pre else None
            row['post_vout_minmax']=[min(r[2] for r in post),max(r[2] for r in post)] if post else None
            row['max_OUT_minus_IN_V']=max(r[2]-r[1] for r in data)
            row['minimum_source_delivery_A']=min(-r[4] for r in data)
            row['post_peak_time_s']=max(post,key=lambda r:r[2])[0] if post else None
    summary.append(row)
    (OUT/'EXECUTION_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(row),flush=True)
    if not row['completed']: break
