"""T25CP: bounded NEW TLV76701 model-scope tests, never board qualification."""
from pathlib import Path
import subprocess, time, hashlib, json, re, csv

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'results'
OUT.mkdir(exist_ok=True)
LIB = ROOT / 'vendor' / 'TLV76701_TRANS.lib'
ENGINE = Path(r'C:\Cadence\OrCADX_25.1\tools\bin\pspice.exe')
assert hashlib.sha256(LIB.read_bytes()).hexdigest() == '8dc150de2dfdf2e7562dd0656970ffc7750537d0f88966fc4f776bf5f71a2e2a'

def deck(name, source, extra, analysis):
    return f'''T25CP {name} - ISOLATED MODEL ONLY, NO OVP OR THERMAL QUALIFICATION
.LIB "{LIB}"
V_SRC VIN 0 {source}
X_LDO VIN FB 0 VIN REG TLV76701_TRANS
R_TOP REG FB 31.6k
R_BOT FB 0 10k
C_IN VIN 0 1u
R_ESR REG CO 0.01
C_OUT CO 0 10u
{extra}
.OPTIONS TNOM=25 NUMDGT=8
.TEMP 25
{analysis}
.PROBE64 V([VIN]) V([REG]) I(V_SRC)
.END
'''

cases = [
 ('reverse_forced_3p3_VIN0', '0', 'V_FORCE REG 0 3.3', '.OP'),
 ('fault12_pulse10us_CC280', 'PWL(0 5.5 2m 5.5 2.001m 12 2.011m 12 2.012m 5.5)', 'I_LOAD REG 0 0.280', '.TRAN 100n 3m 0 20n\n.PRINT TRAN V([VIN]) V([REG]) I(V_SRC)'),
 ('fault12_pulse100us_CC280', 'PWL(0 5.5 2m 5.5 2.001m 12 2.101m 12 2.102m 5.5)', 'I_LOAD REG 0 0.280', '.TRAN 100n 3m 0 20n\n.PRINT TRAN V([VIN]) V([REG]) I(V_SRC)'),
]
summary = []
for name, source, extra, analysis in cases:
    cir = OUT / (name + '.cir')
    if cir.exists():
        raise RuntimeError('Refusing unchanged rerun; existing evidence: ' + name)
    cir.write_text(deck(name, source, extra, analysis), encoding='ascii')
    start = time.monotonic()
    row = {'case':name, 'deck_sha256':hashlib.sha256(cir.read_bytes()).hexdigest(),
           'scope':'MODEL_SCOPE_DIAGNOSTIC; ideal imposed input; no real OVP, thermal, reverse safety or whole-board PASS'}
    with (OUT/(name+'.stdout.txt')).open('wb') as so, (OUT/(name+'.stderr.txt')).open('wb') as se:
        try:
            p = subprocess.run([str(ENGINE), '-r', str(cir)], cwd=OUT, stdout=so, stderr=se,
                               timeout=60, creationflags=subprocess.CREATE_NO_WINDOW)
            row.update(status='ENGINE_RETURNED', returncode=p.returncode)
        except subprocess.TimeoutExpired:
            row.update(status='WALL_TIMEOUT', actual_simulated_progress='UNKNOWN')
        except OSError as e:
            row.update(status='ENGINE_LAUNCH_BLOCKED', error=str(e))
    row['wall_seconds'] = time.monotonic()-start
    outfile = OUT/(name+'.out')
    text = outfile.read_text(errors='replace') if outfile.exists() else ''
    row['job_concluded'] = 'JOB CONCLUDED' in text
    row['errors'] = [l.strip() for l in text.splitlines() if re.search(r'ERROR|FATAL',l,re.I)]
    summary.append(row)
    (OUT/'EXECUTION_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(row), flush=True)
    if row['status'] != 'ENGINE_RETURNED' or not row['job_concluded'] or row['errors']:
        break
