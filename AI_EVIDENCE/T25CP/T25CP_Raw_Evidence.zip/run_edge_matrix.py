"""Predeclared bounded line-edge matrix after T25CP pulse finding, no model edits."""
from pathlib import Path
import json
root=Path(__file__).resolve().parent
source=(root/'run_ng_t25cp.py').read_text()
# Same successful runtime, fixed 20ns profile, no repeated cases or reverse tests.
cases=[]
for peak in [5.9157205069,12.0]:
    for edge_us in [10,100]:
        for cout_u in [0.5,10]:
            name=f'peak{peak:.6f}_edge{edge_us}us_Cout{cout_u}u'
            e=edge_us*1e-6
            stimulus=f'PWL(0 5.5 2m 5.5 {0.002+e:.9f} {peak} {0.002+e+0.0001:.9f} {peak} {0.002+2*e+0.0001:.9f} 5.5)'
            cases.append((name,stimulus,'I_LOAD REG 0 0.280',True))
source=source.replace("OUT=ROOT/'ng-results-v2'","OUT=ROOT/'edge-matrix'")
a=source.index('cases=[')
b=source.index('\nsummary=[]',a)
source=source[:a]+'cases='+repr(cases)+source[b:]
source=source.replace('C_OUT CO 0 10u','C_OUT CO 0 {"0.5u" if "Cout0.5u" in name else "10u"}')
(root/'edge_matrix_generated.py').write_text(source,encoding='utf-8')
exec(compile(source,str(root/'edge_matrix_generated.py'),'exec'))
