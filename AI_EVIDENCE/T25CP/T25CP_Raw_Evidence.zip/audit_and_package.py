"""Independent CSV audit and byte/CRC retention, no simulation reruns."""
from pathlib import Path
import json, hashlib, csv, zipfile, math
R=Path(__file__).resolve().parent
audit=[]
for folder in ['ng-results-v2','edge-matrix']:
    for p in sorted((R/folder).glob('*.csv')):
        with p.open() as f:
            header=f.readline().split()
            rows=[list(map(float,l.split())) for l in f if l.strip()]
        assert len(header)==5 and all(len(r)==5 and all(math.isfinite(x) for x in r) for r in rows)
        tran=len(rows)>1
        log=p.with_suffix('.log').read_text(errors='replace')
        assert 'aborted' not in log.lower() and 'Error:' not in log
        a={'file':p.relative_to(R).as_posix(),'rows':len(rows),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'columns':header}
        if tran:
            # wrdata rounds sub-picosecond adaptive steps to equal printed times.
            # Keep every row and extremum; prohibit backwards time, not rounded duplicates.
            assert all(b[0]>=a[0] for a,b in zip(rows,rows[1:]))
            a['equal_printed_timestamps']=sum(b[0]==q[0] for q,b in zip(rows,rows[1:]))
            assert abs(rows[-1][0]-.003)<1e-12
            pre=[r for r in rows if .0015<=r[0]<=.0019]
            assert min(r[2] for r in pre)>3.15 and max(r[2] for r in pre)<3.5
            assert max(r[2] for r in pre)-min(r[2] for r in pre)<.001
            post=[r for r in rows if r[0]>=.002]
            low=min(post,key=lambda r:r[2]); high=max(post,key=lambda r:r[2])
            a.update(end_s=rows[-1][0],valid_prestate=True,min_V=low[2],min_time_s=low[0],max_V=high[2],max_time_s=high[0],
                     max_out_minus_in_V=max(r[2]-r[1] for r in post),
                     samples_below_2p7=sum(r[2]<2.7 for r in post),samples_above_3p6=sum(r[2]>3.6 for r in post),
                     scope='model nominal line response only' if 'collapse' not in p.name else 'REJECTED_FOR_PHYSICAL_REVERSE_PROOF')
        else:
            a.update(forced_vout_V=rows[0][2],vin_V=rows[0][1],source_delivery_A=-rows[0][4],scope='diagnostic confirms missing reverse path, NOT safety')
        audit.append(a)
(R/'INDEPENDENT_AUDIT.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
model=(R/'vendor/TLV76701_TRANS.lib').read_text()
assert 'G_ABMII1         VIN GND VALUE { IF(V(EN_OK)>0.5, 50u+V(LOAD),1.5u)' in model
scope={'model_sha256':hashlib.sha256((R/'vendor/TLV76701_TRANS.lib').read_bytes()).hexdigest(),
       'reverse_finding':'VIN pin supplied by behavioral current source G_ABMII1; VIN_ORG is an ideal sensed voltage, no physical VOUT-to-VIN body diode. Forced OUT3.3/IN0 reports only +1.5uA source delivery.',
       'reject':'Do not interpret collapse hold-up or absent negative input current as actual reverse blocking.',
       'source_current_warning':'I(V_SRC) includes the ideal 1uF input capacitor current; negative edge spikes are not isolated LDO reverse current.',
       'excluded':['temperature','noise','guaranteed hardware line response','real TS431/PNP/FSS2301S OVP','AA or mux or NRST or SD writing'],
       'baseline_commit':'258d35194e3d91e7795ba1ee8c42765ca0143c34',
       'local_cad_blobs_match':{'01_POWER.SchDoc':'da2d005712c47000eb8c16157eca464d3fee4fe1','07_EXPANSION.SchDoc':'8714da5cbc041923e25a1aa647002e88f5b4d9a3','DATALOGER_RevA.PcbDoc':'c1ad1e246ad0489a1e2879e16b3a5f959489d3af'},
       'runtime_sha256':hashlib.sha256((R/'runtime/Spice64/bin/ngspice_con.exe').read_bytes()).hexdigest(),
       'runtime_archive_sha256':hashlib.sha256((R/'vendor/ngspice-42_64.7z').read_bytes()).hexdigest(),
       'runtime_url':'https://downloads.sourceforge.net/project/ngspice/ng-spice-rework/old-releases/42/ngspice-42_64.7z'}
(R/'MODEL_SCOPE_AUDIT.json').write_text(json.dumps(scope,indent=2),encoding='utf-8')
files=[]
for folder in ['results','ng-results','ng-results-v2','edge-matrix']:
    files.extend(p for p in (R/folder).rglob('*') if p.is_file())
files.extend(R/p for p in ['run_t25cp.py','run_ng_t25cp.py','run_edge_matrix.py','edge_matrix_generated.py','audit_and_package.py','INDEPENDENT_AUDIT.json','MODEL_SCOPE_AUDIT.json','vendor/slvmcy1.zip','vendor/slvmcy2.zip','vendor/TLV76701_TRANS.lib','vendor/tlv767.pdf'])
manifest=[{'path':p.relative_to(R).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(set(files))]
zpath=R/'T25CP_Raw_Evidence.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(set(files)): z.write(p,p.relative_to(R).as_posix())
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None
    for m in manifest: assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
index={'file_name':zpath.name,'bytes':zpath.stat().st_size,'sha256':hashlib.sha256(zpath.read_bytes()).hexdigest(),'crc_pass':True,'members':manifest}
(R/'RAW_MANIFEST.json').write_text(json.dumps(index,indent=2),encoding='utf-8')
print(json.dumps({'analyses_audited':len(audit),'transients':sum(a['rows']>1 for a in audit),'raw_bytes':index['bytes'],'raw_sha256':index['sha256']},indent=2))
for a in audit: print(a['file'],a.get('min_V'),a.get('max_V'),a.get('min_time_s'))
